const app = require('./app')
const pool = require('./config/database')
require('dotenv').config()

//depois preciso mandar isso pro arquivo .env
const PORT = process.env.PORT

async function startServer() {
    try {
        const conection = await pool.getConnection()
        console.log('Banco de dados conectado com sucesso')
        conection.release()

        app.listen(PORT, () => {
            console.log(`Api rodando na porta ${PORT}`)
        })
    } catch (error) {
        console.log('Erro ao conectar no banco de dados', error)
    }
}

startServer()