const express = require('express');
const userRoutes = require('./routes/user_routes');
const authRoutes = require('./routes/auth_routes');
const servicesRoutes = require('./routes/services_routes');
const paymentsRoutes = require('./routes/payments_routes');
const app = express();


app.use(express.json());
app.use('/users',userRoutes);
app.use('/login',authRoutes);
app.use('/services',servicesRoutes);
app.use('/payments',paymentsRoutes)
app.use('/uploads', express.static('uploads'))

module.exports = app;